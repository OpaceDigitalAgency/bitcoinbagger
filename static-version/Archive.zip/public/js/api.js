// BitcoinBagger API loader (static JSON + real APIs)
class BitcoinAPI {
  constructor() {
    this.bitcoinPrice = 0;
    this.bitcoinChange = 0;
    this.COMPANY_JSON = '/data/treasuries.json';
    this.KEYS = {
      TWELVEDATA: '7038b64631ce424ebca83dfd227b079d',
      ALPHA_VANTAGE: 'EGYFO89BDY0WYY04',
      FMP: 'gLUC55COpZ8lqKMtjQuyltUGelxH9Not',
    };
    this.updateInterval = null;
  }

  async fetchBitcoinPrice() {
    const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true');
    if (!res.ok) throw new Error('CoinGecko failed');
    const data = await res.json();
    this.bitcoinPrice = data.bitcoin.usd;
    this.bitcoinChange = data.bitcoin.usd_24h_change;
    return data.bitcoin;
  }

  async fetchCompanyBitcoinHoldings() {
    const res = await fetch('/api/treasuries.php');
    if (!res.ok) throw new Error('Treasuries API error');
    const response = await res.json();

    // Handle new API response format with metadata
    if (response.data && Array.isArray(response.data)) {
      console.log('Live treasuries data loaded:', response.meta);
      return response.data;
    }

    // Fallback for old format
    return Array.isArray(response) ? response : [];
  }

  async fetchStockPrice(symbol) {
    // a) TwelveData
    let res = await fetch(
      `https://api.twelvedata.com/price?symbol=${symbol}&apikey=${this.KEYS.TWELVEDATA}`
    );
    let body = await res.json();
    if (res.ok && !body.code) return parseFloat(body.price);

    // b) Alpha Vantage
    res = await fetch(
      `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.KEYS.ALPHA_VANTAGE}`
    );
    body = await res.json();
    if (body['Global Quote']?.['05. price']) {
      return parseFloat(body['Global Quote']['05. price']);
    }

    // c) FinancialModelingPrep
    res = await fetch(
      `https://financialmodelingprep.com/api/v3/quote/${symbol}?apikey=${this.KEYS.FMP}`
    );
    body = await res.json();
    if (Array.isArray(body) && body[0]?.price) return body[0].price;

    throw new Error(`All stock-price APIs failed for ${symbol}`);
  }

  async fetchOverview(symbol) {
    const res = await fetch(
      `https://www.alphavantage.co/query?function=OVERVIEW&symbol=${symbol}&apikey=${this.KEYS.ALPHA_VANTAGE}`
    );
    if (!res.ok) throw new Error(`Overview fetch failed for ${symbol}`);
    return res.json();
  }

  async fetchCompaniesData() {
    const holdings = await this.fetchCompanyBitcoinHoldings();
    const btcPrice = this.bitcoinPrice || (await this.fetchBitcoinPrice()).usd;

    const companies = await Promise.all(
      holdings.map(async h => {
        const [stockPrice, overview] = await Promise.all([
          this.fetchStockPrice(h.ticker),
          this.fetchOverview(h.ticker)
        ]);

        const btcValue = h.btcHeld * btcPrice;
        const bsp = overview.SharesOutstanding
                   ? btcValue / overview.SharesOutstanding
                   : 0;
        const premium = bsp && stockPrice
                       ? ((bsp - stockPrice) / stockPrice) * 100
                       : 0;

        return {
          ticker: h.ticker,
          name: h.name,
          businessModel: h.businessModel,
          btcHeld: h.btcHeld,
          btcValue,
          stockPrice,
          changePercent: this.bitcoinChange,
          sharesOutstanding: overview.SharesOutstanding || 0,
          marketCap: overview.MarketCapitalization || (stockPrice * overview.SharesOutstanding) || 0,
          bsp,
          premium
        };
      })
    );

    companies.sort((a, b) => b.btcHeld - a.btcHeld);
    companies.forEach((x, i) => x.rank = i + 1);
    return companies;
  }

  /**
   * Fetch NAV for an ETF symbol via FMP
   */
  async fetchNAV(symbol) {
    const res = await fetch(
      `https://financialmodelingprep.com/api/v3/etf/profile/${symbol}?apikey=${this.KEYS.FMP}`
    );
    if (!res.ok) throw new Error(`NAV fetch failed for ${symbol}`);
    const data = await res.json();
    // FMP returns an array with profile objects containing an 'nav' field
    return Array.isArray(data) && data[0]?.nav ? data[0].nav : 0;
  }

  /**
   * Load and enrich ETF holdings from static JSON
   */
  async fetchETFData() {
    // Load real-time ETF holdings from backend
    const res = await fetch('/api/etf-holdings.php');
    if (!res.ok) throw new Error('ETF holdings API error');
    const response = await res.json();

    // Handle new API response format with metadata
    let etfs;
    if (response.data && Array.isArray(response.data)) {
      console.log('Live ETF data loaded:', response.meta);
      etfs = response.data;
    } else {
      // Fallback for old format
      etfs = Array.isArray(response) ? response : [];
    }

    // Ensure we have a current BTC price
    const btcPrice = this.bitcoinPrice || (await this.fetchBitcoinPrice()).usd;

    // For each ETF, fetch live price and NAV, then compute metrics
    const enriched = await Promise.all(
      etfs.map(async e => {
        const [price, nav] = await Promise.all([
          this.fetchStockPrice(e.ticker),
          this.fetchNAV(e.ticker)
        ]);
        const btcPerShare = e.sharesOutstanding > 0 ? e.btcHeld / e.sharesOutstanding : 0;
        const premium = nav > 0 ? ((price - nav) / nav) * 100 : 0;
        return {
          ...e,
          price,
          nav,
          btcPerShare,
          premium
        };
      })
    );

    // Optionally sort by BTC held
    enriched.sort((a, b) => b.btcHeld - a.btcHeld);
    enriched.forEach((x, i) => x.rank = i + 1);
    return enriched;
  }

  async fetchAllData() {
    const [bitcoin, companies, etfs] = await Promise.all([
      this.fetchBitcoinPrice(),
      this.fetchCompaniesData(),
      this.fetchETFData?.() || Promise.resolve([])
    ]);
    return { bitcoin, companies, etfs };
  }
  /**
   * Start auto-refresh every interval ms
   */
  startAutoUpdate(callback, interval = 60000) {
    if (this.updateInterval) clearInterval(this.updateInterval);
    this.updateInterval = setInterval(async () => {
      try {
        const data = await this.fetchAllData();
        callback(data);
      } catch (err) {
        console.error('Auto-update error:', err);
      }
    }, interval);
  }

  /** Stop auto-update loop */
  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }
}
window.bitcoinAPI = new BitcoinAPI();
